package com.b210.damda.domain.dto;

import lombok.Data;

@Data
public class UserSearchDTO {

    private String query;
    private String type;

}
