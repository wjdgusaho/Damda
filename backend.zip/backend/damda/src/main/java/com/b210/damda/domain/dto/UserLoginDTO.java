package com.b210.damda.domain.dto;

import lombok.Data;

@Data
public class UserLoginDTO {

    private String email;
    private String userPw;

}
