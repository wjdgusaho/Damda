package com.b210.damda.util.emailAPI.dto;

import lombok.Data;

@Data
public class TempCodeDTO {
    private String email;
    private String code;

}